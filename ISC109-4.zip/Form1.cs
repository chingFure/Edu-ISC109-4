﻿/// 教育部工科技藝競賽 109 年第四題 凸形直線環繞
/// 漆家豪 於 海青工商 2024/2/22
using _109_4;
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;

namespace _109_4
{
    public struct Coordinate
    {
        public int xy, wh;
        public Coordinate() { xy = wh = 0; }
        public Coordinate(int _xy, int _wh) { xy = _xy; wh = _wh; }
    }

    public partial class Form1 : Form
    {
        public const int pointMax = 6;//最多 3 個方塊 
        public const int MinLocationX = 20;//方塊 x 基礎位置最小值
        public const int MinLocationY = 20;//方塊 y 基礎位置最小值
        public const int MinWidth = 20;//方塊最小寬度
        public const int MinHeight = 20;//方塊最小高度
        public const int MaxWidth = 80;//方塊最大寬度
        public const int MaxHeight = 80;//方塊最大高度

        public readonly Pen[] pens = {//外框樣式陣列
            new Pen(Color.Black) { DashStyle = DashStyle.Dash },
            new Pen(Color.Black) { DashStyle = DashStyle.Dot },
            new Pen(Color.Black) { DashStyle = DashStyle.DashDot },
            new Pen(Color.Black) { DashStyle = DashStyle.DashDotDot}
        };
        public readonly Coordinate[][] xyPairs = new Coordinate[][] {
            new Coordinate[] { new Coordinate(0, 3), new Coordinate(1, 4), new Coordinate(2, 5) },
            new Coordinate[] { new Coordinate(0, 3), new Coordinate(1, 5), new Coordinate(2, 4) },
            new Coordinate[] { new Coordinate(0, 4), new Coordinate(1, 3), new Coordinate(2, 5) },
            new Coordinate[] { new Coordinate(1, 3), new Coordinate(0, 4), new Coordinate(2, 5) },
            new Coordinate[] { new Coordinate(1, 4), new Coordinate(0, 3), new Coordinate(2, 5) },
            new Coordinate[] { new Coordinate(1, 5), new Coordinate(0, 3), new Coordinate(2, 4) }
        };
        private List<Rectangle> blocks = new List<Rectangle>();//方塊序列
        private Random random = new Random((int)DateTime.Now.Ticks);//亂數物件
        private Bitmap image;//儲存影像
        private static List<PointF> boundaryPoints = new List<PointF>(); //儲存邊界點的清單

        public Form1()
        {
            InitializeComponent();
        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            this.Close();//關閉應用程式
        }

        /// <summary>
        /// 按下「隨機產生方塊」按鈕時的事件處理程序
        /// </summary>
        /// <param name="sender">引發事件的物件</param>
        /// <param name="e">有關事件的資訊</param>
        private void RandBtn_Click(object sender, EventArgs e)
        {
            image = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            GenerateRandomBlocks(); //隨機產生方塊
            drawRectangle(); //繪製方塊外框
            Invalidate(); //觸發重繪事件
        }

        // 繪製方塊外框
        /// <summary>
        /// 依照 blocks 繪製方塊外框
        /// </summary>
        private void drawRectangle()
        {
            Graphics graphics = pictureBox1.CreateGraphics();//建立繪圖介面
            graphics.Clear(Color.White); //清除畫布
            for (int i = 0; i < blocks.Count; i++)
            {
                Pen pen = pens[i]; //依序使用外框樣式
                pen.Width = 3; //加粗線條
                graphics.DrawRectangle(pen, blocks[i]); //繪製方塊外框
            }
        }
        /// <summary>
        /// 隨機產生方塊
        /// </summary>
        private void GenerateRandomBlocks()
        {
            blocks.Clear();  // 清空所有方塊
            int[] xx = new int[pointMax], yy = new int[pointMax];
            xx[0] = MinLocationX + random.Next(MinWidth, MaxWidth + 1);
            yy[0] = MinLocationY + random.Next(MinHeight, MaxHeight + 1);
            for (int i = 1; i < pointMax; i++)//隨機生成點的位置
            {
                xx[i] = xx[i - 1] + random.Next(MinWidth, MaxWidth + 1);
                yy[i] = yy[i - 1] + random.Next(MinHeight, MaxHeight + 1);
            }
            int width, height;
            int indexX, indexY;
            indexX = random.Next(0, xyPairs.Length);
            indexY = random.Next(0, xyPairs.Length);
            for (int j = 0; j < pointMax / 2; j++)
            {
                int x = xyPairs[indexX][j].xy;
                width = xx[xyPairs[indexX][j].wh] - xx[x];
                int y = xyPairs[indexY][j].xy;
                height = yy[xyPairs[indexY][j].wh] - yy[y];
                Rectangle block = new Rectangle(xx[x], yy[y], width, height);//建立方塊
                blocks.Add(block);//加入方塊到方塊序列
            }
            //依照 blocks[0] ~ blocks[2] 劃出矩形框線 (黑色,2pt)
            using (Graphics g = Graphics.FromImage(image))
            {
                for (int i = 0; i < blocks.Count; i++)
                {
                    g.DrawRectangle(new Pen(Color.Black, 2), blocks[i]);
                }
            }
        }
        ///<summary>
        ///連接外框線 
        ///</summary>
        ///<param name="sender">引發事件的物件</param>
        ///<param name="e">有關事件的資訊</param>
        private void ConvexBtn_Click(object sender, EventArgs e)
        {
            boundaryPoints.Clear();
            GenerateBoundaryPoints();//找出合併後的邊界框的所有端點
            using (Graphics g = Graphics.FromImage(image))//連接所有端點，形成外框線
            {
                Pen pen = new Pen(Color.Red, 6);
                g.DrawLines(pen, boundaryPoints.ToArray());
                g.DrawLines(pen, new PointF[] { boundaryPoints.First(), boundaryPoints.Last() });
            }
            pictureBox1.Image = image;//將修改後的影像顯示在 PictureBox 上
        }
        /// <summary>
        /// 產生邊緣的頂點
        /// </summary>
        private void GenerateBoundaryPoints()
        {
            for (int i = 0; i < blocks.Count; i++)//加入方塊 4 個點座標
            {
                addBoundaryPoints(i);
            }
            for (int i = 0; i < blocks.Count - 1; i++)
                for (int j = i + 1; j < blocks.Count; j++)
                    FindInternalVertex(i, j);//加入交點
            boundaryPoints = boundaryPoints.Distinct().ToList();//刪除重複的點
            for (int i = boundaryPoints.Count - 1; i >= 0; i--)
            {
                if (IsPointInsideBlocks(boundaryPoints[i], blocks))
                {
                    boundaryPoints.RemoveAt(i);
                }
            }
            SortSequence();
        }

        /// <summary>
        /// 檢查點是否在矩形内部的
        /// </summary>
        /// <param name="point">點</param>
        /// <param name="blocks">所有組合成的矩形</param>
        /// <returns>若在裡面則傳回真</returns>
        private static bool IsPointInsideBlocks(PointF point, List<Rectangle> blocks)
        {
            bool insideFlag = false;
            foreach (var block in blocks)
            {
                insideFlag = insideFlag ||
                    ((point.X < block.Right) && (point.X > block.Left) &&
                     (point.Y > block.Top) && (point.Y < block.Bottom));
            }
            return insideFlag;
        }

        /// <summary>
        /// 判斷 4 個點是否有交點
        /// </summary>
        /// <param name="p1">直線 1 的 x1,y1 </param>
        /// <param name="p2">直線 1 的 x2,y2</param>
        /// <param name="p3">直線 2 的 x1,y1</param>
        /// <param name="p4">直線 2 的 x2,y2</param>
        /// <returns>傳回交點，無交點傳回 NULL</returns>
        private PointF intersect(PointF p1, PointF p2, PointF p3, PointF p4)
        {
            if ((Math.Min(p1.X, p2.X) < p3.X) && (Math.Max(p1.X, p2.X) > p3.X) &&
               (Math.Min(p3.Y, p4.Y) < p1.Y) && (Math.Max(p3.Y, p4.Y) > p1.Y))
                return (new PointF(p3.X, p1.Y));
            if ((Math.Min(p3.X, p4.X) < p1.X) && (Math.Max(p3.X, p4.X) > p1.X) &&
                (Math.Min(p1.Y, p2.Y) < p3.Y) && (Math.Max(p1.Y, p2.Y) > p3.Y))
                return (new PointF(p1.X, p3.Y));
            return (PointF.Empty);
        }

        /// <summary>
        /// 尋找 block[a] 與 block[b] 四條邊各自交點
        /// </summary>
        /// <param name="a">blocks 的索引 a</param>
        /// <param name="b">blocks 的索引 b</param>
        private void FindInternalVertex(int a, int b)
        {
            PointF t;
            PointF[] pointsA = { new PointF(blocks[a].Left, blocks[a].Top), new PointF(blocks[a].Right, blocks[a].Top),
                         new PointF(blocks[a].Right, blocks[a].Bottom), new PointF(blocks[a].Left, blocks[a].Bottom) };
            PointF[] pointsB = { new PointF(blocks[b].Left, blocks[b].Top), new PointF(blocks[b].Right, blocks[b].Top),
                         new PointF(blocks[b].Right, blocks[b].Bottom), new PointF(blocks[b].Left, blocks[b].Bottom) };
            for (int i = 0; i < pointsA.Length; i++)
            {
                for (int j = 0; j < pointsB.Length; j++)
                {
                    if ((t = intersect(pointsA[i], pointsA[(i + 1) % 4], pointsB[j], pointsB[(j + 1) % 4])) != PointF.Empty)
                    {
                        boundaryPoints.Add(t);
                    }
                }
            }
        }
        /// <summary>
        /// 排序外框頂點，使其連續
        /// </summary>
        static void SortSequence()
        {
            bool isX = false;
            float lastX = boundaryPoints.First().X;
            float lastY = boundaryPoints.First().Y;
            float minDistance, lastX_Y = lastX , lastY_X = lastY;
            for (int i = 1; i < boundaryPoints.Count - 1; i++)
            {
                int swapIndex = -1;
                if (isX)
                {
                    minDistance = float.MaxValue;
                    for (int j = i; j < boundaryPoints.Count; j++)
                    {
                        if (boundaryPoints[j].X == lastX)
                        {
                            if(minDistance > Math.Abs(boundaryPoints[j].Y - lastX_Y))
                            {
                                swapIndex = j;
                                lastY = boundaryPoints[j].Y;
                                minDistance = Math.Abs(boundaryPoints[j].Y - lastX_Y);
                            }
                        }
                    }
                }
                else
                {
                    minDistance = float.MaxValue;
                    for (int j = i; j < boundaryPoints.Count; j++)
                    {
                        if (boundaryPoints[j].Y == lastY)
                        {
                            if (minDistance > Math.Abs(boundaryPoints[j].X - lastY_X))
                            {
                                swapIndex = j;
                                lastX = boundaryPoints[j].X;
                                minDistance = Math.Abs(boundaryPoints[j].X - lastY_X);
                            }
                        }
                    }
                }
                if (swapIndex != -1)
                {
                    PointF temp = boundaryPoints[i];
                    boundaryPoints[i] = boundaryPoints[swapIndex];
                    boundaryPoints[swapIndex] = temp;
                    lastY_X = boundaryPoints[i].X; lastX_Y = boundaryPoints[i].Y;
                }
                isX = !isX;
            }
        }
        /// <summary>
        /// 將一組矩形 4 個點加入外框頂點
        /// </summary>
        /// <param name="index">3 組矩形框的索引</param>
        public void addBoundaryPoints(int index)
        {
            boundaryPoints.Add(new PointF(blocks[index].Left, blocks[index].Top));
            boundaryPoints.Add(new PointF(blocks[index].Right, blocks[index].Top));
            boundaryPoints.Add(new PointF(blocks[index].Right, blocks[index].Bottom));
            boundaryPoints.Add(new PointF(blocks[index].Left, blocks[index].Bottom));
        }
    }
}
